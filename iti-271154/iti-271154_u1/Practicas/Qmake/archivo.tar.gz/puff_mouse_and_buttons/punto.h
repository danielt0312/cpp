#pragma once

class Punto {
private:
    int X;
    int Y;
public:

    Punto(int X, int Y);
    int getX ();
    int getY ();
};
