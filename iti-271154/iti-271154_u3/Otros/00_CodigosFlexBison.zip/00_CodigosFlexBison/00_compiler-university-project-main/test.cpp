// Program example
#include <iostream>

using namespace std;

int x,y;
float z;
int main()
{
cin >> x >> y;
cout << x << "\n";
cout << y << "\n";
cout <<  "\n";
while( y >= 0 ) {
// execute 2
cout << y << "\n";
y = y - 1;
z = z * 2;
}
y = x - 1;
return 0;
}
