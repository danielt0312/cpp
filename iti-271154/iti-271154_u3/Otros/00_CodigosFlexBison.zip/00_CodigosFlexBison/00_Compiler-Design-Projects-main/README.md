## A Basic Compiler | <sub> _C, Flex, Bison_ </sub>
Built a project to understand the working basics of compiling for academic purposes, where I customized a programming
language that can be compiled using Flex and Bison.
